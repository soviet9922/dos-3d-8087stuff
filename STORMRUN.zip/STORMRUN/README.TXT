STORM RUN  -  flat-shaded 3D rail shooter for the IBM PC
Requires: 8088 or later, 8087 math coprocessor, CGA, DOS 2+

FILES
  STORMRUN.COM   the game
  SRGOD.COM      test build: invulnerable
  SRBOSS.COM     test build: invulnerable, starts just before the boss
  DOSBOX.CONF    DOSBox settings (machine=cga)

RUN
  Real PC / emulator:  STORMRUN
  DOSBox:              dosbox -conf DOSBOX.CONF   (from this folder)
  86Box/PCem: IBM PC/XT + 8087 + CGA, copy the files to a DOS disk.

CONTROLS
  Arrows / WASD   fly
  Space / Ctrl    fire (lasers follow your sideways motion: steer to aim)
  Z / X           dodge roll (bullets bounce off while rolling)
  B               bomb (clears fighters and bullets, hurts the boss)
  P pause   C palette   M sound   F frame-rate counter
  Esc             back to title / quit

NOTES
  DOSBox treats 8087 instructions as almost free, so it runs much faster
  than a real 4.77 MHz XT would (estimated 3-5 fps there).
  The game refuses to start without an 8087.
